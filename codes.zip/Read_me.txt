Travaille réaliser par: 
 	   =>nom et prénom: Said Ben Hassane Samir | email: samirsaidhassane@gmail.com
           =>Nom et prénom: Hounkponou Ines Joelle Assia | email: himsjoyce@gmail.com
Commandes pour Admin
ADMIN (pour se connecter)
ENCHERE desc##prix##temps(min) (pour créer une enchere)


Commandes pour Membre
LOGIN nom (pour se connecter)
ENCHRERES (pour voir toutes les encheres)
ENCHREREC (pour voir toutes les encheres en cours)
OFFRE idEnchere##prix (pour proposer une offre pour une enchere)
OFFRES (pour voir les offres que tu as fait)
OFFREG (pour voir les offres que tu as gagné)